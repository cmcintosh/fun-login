// let rlSync = require('readline-sync');
// let name = rlSync.question("What's your name?\n");
// console.log(`Good Morning, ${name}!`);

let name = prompt("What's your name lil homie?");
console.log(`Good Morning, ${name}`);