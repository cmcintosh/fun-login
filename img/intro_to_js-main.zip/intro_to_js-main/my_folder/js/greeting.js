let name = 'Heero_Stranger';
for (let i = 0; i <3; i++){
    console.log('Good Morning, ' + name);
    console.log('Good Afternoon, ' + name);
}
console.log('Good Evening, ' + name);