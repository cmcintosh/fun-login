//we writing some shit today
/*
-We qill use Camel case and SSC 
-we will us ';' when we can make it a habit
*/
console.log('Hello, world!'.toLowerCase());
console.log('Hello, world!'.length);

/*
Some good command line prompts

#how to look in dir
ls 'file_name'

#how to move thing in files 
mv <source file> <destination path>
(this will cut the items and move them to cp 'file_name')

#pasting files moved via mv
cp 'file_name  (will paste any mv file_name content'

# Create a folder named new_dir
mkdir new_dir

# Navigate into the new_dir folder
cd new_dir

# Create a file called new_file.js
touch new_file.js

# Create a file called new_file.js
touch new_file.js

# Navigate out of the current folder to the one above it
cd ..

#open js file
cod 'file_name'

#to remove js fiels or anything really use
rm 'file_name'

#to remove things you not sure of and want back use 
shred 'file_name'

#if you want a list of all the commands use

rm --help

# Delete the new_dir folder and the file new_file.js
rm -R new_dir */

// how to exit node terminal 
// .exit or ctr + D or crtl + C to exit node terminal