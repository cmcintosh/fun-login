let rlSync = require ('readline-sync');
let first_name = rlSync.question('What yea first name is lil homie\n');
let last_name = rlSync.question('What yea last name is lil homie\n');
console.log(`Hey lil ${first_name} ${last_name}!`);