// //this is our variable
// let age = 21;

// // we want to add 10, 20, 30 and 40 to the age and print them 

// console.log('Iam ' + age +' years old mother lover ')
// console.log("In " + (age-11) + "years, you will be " + (age+10)+ " years old")
// console.log(`In ${age-11} years, you will be ${age+10} years old`)


// for (let i = 10; i<=40; i+=10){
//     let newage = age + i;
//     console.log("In " + i +"years, you will be  " + newage + " years old")
// }
// this is out of scoop and will not work because of the {} removing them will let it work 
// {
//     let foo = 'bar';
//   }
  
//     console.log(foo);
//var will make any variable become line one ak the golbal variable avoid using
// let foo = 'bar';
{
  var foo = 'qux';
}

console.log(foo);