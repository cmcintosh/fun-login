// function say() {
//     console.log("Output from say()");
// }

// console.log("First");
// say();

// console.log("Last");

//we have to call consol.log every time a function can do this without repeat code
// console.log("hello");
// console.log("hi");
// console.log("how do you do");
// console.log("Quite all right");

//you dont need a declaration it will fill with any value string or info
function say(text) {
    console.log(text);
  }
  
  say("hello");
  say('123');
  say("how do you do");
  say("Quite all right");