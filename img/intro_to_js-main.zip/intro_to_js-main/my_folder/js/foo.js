let foo = "bar";
console.log(foo);
foo;

